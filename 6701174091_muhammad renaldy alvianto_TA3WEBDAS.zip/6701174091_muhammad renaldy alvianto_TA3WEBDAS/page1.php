<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<form action="" method="post">
		<input type="text" name="user" placeholder="Username" required><br>
			<input type="password" name="pass" placeholder="Password" required><br>
				<input type="submit" name="submit" value="Login">&nbsp&nbsp&nbsp
					<a href="page2.php">Signup</a>
	</form>
</body>
</html>

<?php
		session_start();
		include "konek.php";
	if (isset($_POST['submit'])) {
		$username = $_POST['user'];
		$password = md5($_POST['pass']);
 	$smpn = mysqli_query($con, "SELECT * from user where Username='$username' AND Password='$password'");
 	$ck = mysqli_fetch_row($smpn);

 		if ($ck > 0) {
 				$_SESSION['user'] = $username;
 				header("Location:page3.php");
 		}
 			else{
 				echo "<script>alert('Login failed')</script>";
 			}

 	}
?>
