<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
</head>
<body>
	<form action="page2.php" method="post">
		<input type="text" name="user" placeholder="Username" required><br>
			<input type="password" name="pass" placeholder="Password" required><br>
				<input type="password" name="repass" placeholder="Re-Password" required><br>
		<input type="submit" name="signup" value="Signup">&nbsp&nbsp&nbsp
		<a href="page1.php">Login</a>
	</form>
</body>
</html>

<?php
	include 'konek.php';
if(isset($_POST['signup'])){
	
$username = $_POST['user'];
$password = md5($_POST['pass']);

		$query = "INSERT INTO user (Username,Password) VALUES ('$username','$password')";
		$result = mysqli_query($con,$query);

		if($result){
		echo "Berhasil";
		}else{
		  echo "Gagal";
		}
}
?>