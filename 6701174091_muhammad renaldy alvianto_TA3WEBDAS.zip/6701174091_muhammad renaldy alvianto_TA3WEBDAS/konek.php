<?php
  $con = mysqli_connect('localhost','root','','ta2') or die (mysql_error());

 ?>
