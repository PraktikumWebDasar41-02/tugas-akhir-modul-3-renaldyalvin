<!DOCTYPE html>
  <html>
    <head>
      <title>Upload</title>
    </head>
  <body>
          <form action="page3.php" method="post" enctype="multipart/form-data">
    <?php
        session_start(); 
          echo $_SESSION['user']; 
      ?>
              <input type="submit" name="out" value="Logout"><br><br>
              Upload Foto &nbsp&nbsp&nbsp <input type="file" name="poto"> <br><br>
              <input type="submit" name="submit" value="Upload">
  </form>
    </body>
      </html>

<?php
  include "konek.php";
    $user =  $_SESSION['user'];
        if (isset($_POST['submit'])) {
        $file = 'foto/';
          $cc = $file.basename($_FILES['poto']['name']);
            $smpn = "INSERT INTO `Upload` (`Username`, `Gambar`) VALUES ('$user', '$cc');";

        if ($con->query($smpn) === true) {
             echo "<br>UPLOADED";
              } else {
                  echo "<br>Connection failed" . $con->error;
            }

         }
?>

<center><h2>Timeline</h2></center>
  <table border="0">
    <?php
    include "konek.php";
    $smpn = mysqli_query($con, "SELECT * from Upload WHERE Username = '$user'");
        $a=1;
        $poto = mysqli_fetch_row($smpn);
            foreach ($smpn as $row){
           
                echo "<td><center><img height='170px' src=foto/".$poto['1']."></td></center>";
              $a++;
          if ($a>4) {
            echo "<tr></tr>";
              $a = 1;
          }
      }
    ?>
  </table>
  <?php
        if (isset($_POST['out'])) {
            session_destroy();
              $kon->close();
                header("Location:page1.php");
            }
    ?>